<?php

class ModBuyPolicy
{

    public static function getDataFromLisk($params)
    {
	return 'Hello, World!';
    }
}